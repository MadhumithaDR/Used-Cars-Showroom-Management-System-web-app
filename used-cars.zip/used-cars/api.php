<?php

// Replace these values with your actual MySQL database credentials
$servername = "localhost";
$username = "root";
$password = "amaraa";
$database = "used_cars";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set response header to JSON
header('Content-Type: application/json');

// Fetch cars based on brand, year, and budget
$brand = isset($_GET['brand']) ? $_GET['brand'] : '';
$year = isset($_GET['year']) ? $_GET['year'] : '';
$budget = isset($_GET['budget']) ? $_GET['budget'] : '';

$sql = "SELECT * FROM cars WHERE 1";

if (!empty($brand)) {
    $sql .= " AND brand = '$brand'";
}

if (!empty($year)) {
    $sql .= " AND year = $year";
}

if (!empty($budget)) {
    $sql .= " AND price <= $budget";
}

$result = $conn->query($sql);

if ($result === false) {
    die('Error executing query: ' . $conn->error);
}

if ($result->num_rows > 0) {
    // Convert result to associative array
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode($data);
} else {
    echo json_encode([]);
}

$conn->close();
?>
